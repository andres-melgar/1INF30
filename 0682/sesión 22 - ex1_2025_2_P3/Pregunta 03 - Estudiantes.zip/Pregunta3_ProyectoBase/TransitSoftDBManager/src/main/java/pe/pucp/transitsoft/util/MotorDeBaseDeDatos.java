package pe.pucp.transitsoft.util;

public enum MotorDeBaseDeDatos {
    MYSQL, MSSQL
}
