package pe.pucp.transitsoft.model;

public enum EstadoCapturaDTO {
    REGISTRADO, 
    PROCESADO
}
