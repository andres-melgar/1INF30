package pe.pucp.transitsoft.daoImp.util;

public enum Tipo_Operacion {
    INSERTAR, MODIFICAR, ELIMINAR
}
